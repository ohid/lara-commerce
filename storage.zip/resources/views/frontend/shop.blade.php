@extends('frontend.app')

@section('title', 'Shop - Lara Ecommerce ')

@section('content')
    <div class="product-big-title-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="product-bit-title text-center">
                        <h2>Shop</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <div class="single-product-area">
        <div class="zigzag-bottom"></div>
        <div class="container">
            <div class="row">
            	@foreach($products as $product)
            	<div class="col-md-3 col-sm-6">
                    <div class="single-shop-product">
                        <div class="product-upper">
                        	@foreach($product->photos as $key => $photo)
                        		@if($key === 0)
                            		<img src="{{ $photo->paths }}" alt="" class="shop-product-img">
                        		@endif
                        	@endforeach
                        </div>
                        <h2><a href="/{{ $product->id }}">{{ $product->name }}</a></h2>
                        <div class="product-carousel-price">
                            <ins>${{ $product->price }}</ins> <del>${{ $product->old_price }}</del>
                        </div>  
                        
                        <div class="product-option-shop">
                        {!! Form::open(array('method' => 'post', 'route' => ['addToCart', $product->id])) !!}
                            <button type="submit">Add to cart</button>
                        {!! Form::close() !!}
                        </div>                       
                    </div>
                </div>
                @endforeach
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <div class="product-pagination text-center">
                        <nav>
                          {!! $products->render() !!}
                        </nav>                        
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection